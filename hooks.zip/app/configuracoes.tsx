import { Platform, SafeAreaView, StyleSheet, Text, View } from 'react-native';

export default function ConfiguracoesScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <Text style={styles.title}>Configurações</Text>
        <Text style={styles.subtitle}>Área inicial para ajustes do aplicativo.</Text>

        <View style={styles.card}>
          <Text style={styles.label}>Plataforma</Text>
          <Text style={styles.value}>{Platform.OS}</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>Modo atual</Text>
          <Text style={styles.value}>MVP local com SQLite + Expo Router</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>Próximo passo sugerido</Text>
          <Text style={styles.value}>Conectar login e sincronização com a API do portal web.</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#F4F6F8' },
  container: { flex: 1, padding: 20 },
  title: { fontSize: 28, fontWeight: '800', color: '#1F2937', marginBottom: 6 },
  subtitle: { fontSize: 16, color: '#6B7280', marginBottom: 18 },
  card: { backgroundColor: '#FFF', borderRadius: 18, padding: 16, marginBottom: 12 },
  label: { fontSize: 15, fontWeight: '700', color: '#374151', marginBottom: 6 },
  value: { fontSize: 16, color: '#111827' },
});
